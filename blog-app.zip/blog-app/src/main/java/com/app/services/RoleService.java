package com.app.services;

import java.util.List;

import com.app.entities.Role;

public interface RoleService {

    Role createRole(Role role);

    Role updateRole(Role role, int roleId);

    Role getRoleById(int roleId);

    List<Role> getAllRoles();

    void deleteRole(int roleId);
}
