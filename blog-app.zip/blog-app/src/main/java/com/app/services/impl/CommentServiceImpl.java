package com.app.services.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entities.Comment;
import com.app.entities.Post;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.CommentDto;
import com.app.repositories.CommentRepo;
import com.app.repositories.PostRepo;
import com.app.services.CommentService;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepo commentRepo;

    @Autowired
    private PostRepo postRepo;
    
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public CommentDto createComment(CommentDto commentDto, Integer postId) {
        Post post = postRepo.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "postId", postId));

        Comment comment = new Comment();
        comment.setContent(commentDto.getContent());
        comment.setPost(post);

        Comment savedComment = commentRepo.save(comment);

        CommentDto response = new CommentDto();
        response.setId(savedComment.getId());
        response.setContent(savedComment.getContent());
        response.setPostId(post.getPostId());

        return response;
    }

    @Override
    public void deleteComment(Integer commentId) {
        Comment comment = commentRepo.findById(commentId)
                .orElseThrow(() -> new ResourceNotFoundException("Comment", "commentId", commentId));
        commentRepo.delete(comment);
    }

    @Override
    public List<CommentDto> getCommentsByPost(Integer postId) {
        Post post = postRepo.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "postId", postId));

        List<Comment> comments = commentRepo.findByPost(post);

        return comments.stream().map(c -> {
            CommentDto dto = new CommentDto();
            dto.setId(c.getId());
            dto.setContent(c.getContent());
            dto.setPostId(post.getPostId());
            return dto;
        }).collect(Collectors.toList());
    }
    
    @Override
    public CommentDto updateComment(CommentDto commentDto, Integer commentId) {
        Comment comment = this.commentRepo.findById(commentId)
                .orElseThrow(() -> new ResourceNotFoundException("Comment", "id", commentId));

        comment.setContent(commentDto.getContent()); // only update content
        Comment updatedComment = this.commentRepo.save(comment);

        return this.modelMapper.map(updatedComment, CommentDto.class);
    }

}
