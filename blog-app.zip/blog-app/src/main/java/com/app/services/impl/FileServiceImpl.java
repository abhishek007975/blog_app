package com.app.services.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.app.services.FileService;

@Service
public class FileServiceImpl implements FileService {

    // Method to upload an image
    @Override
    public String uploadImage(String path, MultipartFile file) throws IOException {
        // Get the original file name
        String name = file.getOriginalFilename();

        // Generate a random file name (to avoid duplicate names)
        String randomID = UUID.randomUUID().toString();
        String fileName1 = randomID.concat(name.substring(name.lastIndexOf(".")));

        // Full path where file will be stored
        String filePath = path + File.separator + fileName1;

        // Create folder if not created already
        File f = new File(path);
        if (!f.exists()) {
            f.mkdir();
        }

        // Copy the file to the target location
        Files.copy(file.getInputStream(), Paths.get(filePath));

        return fileName1; // return the new file name
    }

    // Method to fetch a resource (like an image) by filename
    @Override
    public InputStream getResource(String path, String fileName) throws FileNotFoundException {
        // Full path of the file
        String fullPath = path + File.separator + fileName;

        // Create InputStream to read the file
        InputStream is = new FileInputStream(fullPath);

        return is;
    }
}
