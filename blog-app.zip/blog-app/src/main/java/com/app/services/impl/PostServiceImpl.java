package com.app.services.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort;


import com.app.entities.Category;
import com.app.entities.Post;
import com.app.entities.User;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.CategoryDto;
import com.app.payloads.PostDto;
import com.app.payloads.PostResponse;
import com.app.payloads.UserDto;
import com.app.repositories.CategoryRepo;
import com.app.repositories.PostRepo;
import com.app.repositories.UserRepo;
import com.app.services.PostService;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostRepo postRepo;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private ModelMapper modelMapper;

    // Convert DTO → Entity
    private Post dtoToPost(PostDto postDto) {
        Post post = modelMapper.map(postDto, Post.class);

        User user = userRepo.findById(postDto.getUser().getId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", postDto.getUser().getId()));

        Category category = categoryRepo.findById(postDto.getCategory().getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", postDto.getCategory().getCategoryId()));

        post.setUser(user);
        post.setCategory(category);

        return post;
    }

    // Convert Entity → DTO
    private PostDto postToDto(Post post) {
        PostDto dto = modelMapper.map(post, PostDto.class);
        dto.setUser(modelMapper.map(post.getUser(), UserDto.class));
        dto.setCategory(modelMapper.map(post.getCategory(), CategoryDto.class));
        return dto;
    }

    @Override
    public PostDto createPost(PostDto postDto) {
        Post post = dtoToPost(postDto);
        Post savedPost = postRepo.save(post);
        return postToDto(savedPost);
    }

    @Override
    public PostDto updatePost(PostDto postDto, Integer postId) {
        Post post = postRepo.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));

        post.setTitle(postDto.getTitle());
        post.setContent(postDto.getContent());
        post.setImageName(postDto.getImageName());

        if (postDto.getCategory() != null) {
            Category category = categoryRepo.findById(postDto.getCategory().getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", postDto.getCategory().getCategoryId()));
            post.setCategory(category);
        }

        if (postDto.getUser() != null) {
            User user = userRepo.findById(postDto.getUser().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("User", "id", postDto.getUser().getId()));
            post.setUser(user);
        }

        Post updatedPost = postRepo.save(post);
        return postToDto(updatedPost);
    }

    @Override
    public void deletePost(Integer postId) {
        Post post = postRepo.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));
        postRepo.delete(post);
    }

    // ✅ Pagination-enabled getAllPost
    @Override
    public PostResponse getAllPost(Integer pageNumber, Integer pageSize, String sortBy, String sortDir) {

        // Validate sortBy
        if (!List.of("postId", "title", "content").contains(sortBy)) {
            sortBy = "postId"; // fallback to default
        }

        // Determine sort direction
        Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();

        // Create pageable object with sorting
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

        // Fetch paged posts from DB
        Page<Post> pagePosts = postRepo.findAll(pageable);

        // Map to DTOs
        List<PostDto> postDtos = pagePosts.getContent().stream().map(this::postToDto).toList();

        // Build response
        PostResponse postResponse = new PostResponse();
        postResponse.setContent(postDtos);
        postResponse.setPageNumber(pagePosts.getNumber());
        postResponse.setPageSize(pagePosts.getSize());
        postResponse.setTotalElements(pagePosts.getTotalElements());
        postResponse.setTotalPages(pagePosts.getTotalPages());
        postResponse.setLastPage(pagePosts.isLast());

        return postResponse;
    }



    @Override
    public PostDto getPostById(Integer postId) {
        Post post = postRepo.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "id", postId));
        return postToDto(post);
    }

    @Override
    public List<PostDto> getPostByCategory(Integer categoryId) {
        Category category = categoryRepo.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", categoryId));
        return postRepo.findByCategory(category).stream().map(this::postToDto).collect(Collectors.toList());
    }

    @Override
    public List<PostDto> getPostByUser(Integer userId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        return postRepo.findByUser(user).stream().map(this::postToDto).collect(Collectors.toList());
    }

    @Override
    public List<PostDto> searchPosts(String keyword) {
        return postRepo.findByTitleContaining(keyword).stream().map(this::postToDto).collect(Collectors.toList());
    }
}
