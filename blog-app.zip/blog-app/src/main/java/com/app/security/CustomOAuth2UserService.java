package com.app.security;

import com.app.entities.User;
import com.app.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

@Service
public class CustomOAuth2UserService extends DefaultOAuth2UserService {

    @Autowired
    private UserRepo userRepo;

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest)
            throws OAuth2AuthenticationException {

        // Load user info from provider (Google, GitHub, etc.)
        OAuth2User oAuth2User = super.loadUser(userRequest);

        // Extract user info
        String email = oAuth2User.getAttribute("email");
        String name = oAuth2User.getAttribute("name");

        // Check if user already exists in DB
        Optional<User> userOptional = userRepo.findByEmail(email);

        User user;
        if (userOptional.isPresent()) {
            user = userOptional.get();
        } else {
            // If user does not exist, create a new one
            user = new User();
            user.setName(name != null ? name : email);
            user.setEmail(email);
            user.setPassword("OAUTH_USER"); // dummy password since OAuth handles auth
            user.setAbout("User signed up via OAuth2");
            // TODO: set default role (USER)
            userRepo.save(user);
        }

        // Return Spring Security OAuth2User with authorities
        return new DefaultOAuth2User(
                Collections.singleton(() -> "ROLE_USER"), // default role
                oAuth2User.getAttributes(),
                "email" // key used for username
        );
    }
}
