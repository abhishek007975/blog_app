package com.app.config;

import com.app.security.JwtAuthenticationFilter;
import com.app.security.CustomOAuth2UserService;
import com.app.security.OAuth2LoginSuccessHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableWebMvc
public class SecurityConfig {

    @Autowired
    private JwtAuthenticationFilter jwtFilter;

    @Autowired
    private CustomOAuth2UserService customOAuth2UserService;

    @Autowired
    private OAuth2LoginSuccessHandler oAuth2LoginSuccessHandler;

    // ✅ Correct whitelist for Springdoc (Swagger)
    private static final String[] SWAGGER_WHITELIST = {
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/swagger-ui.html"
    };

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                // Swagger docs open for everyone
                .requestMatchers(SWAGGER_WHITELIST).permitAll()

                // JWT-based authentication endpoints
                .requestMatchers("/api/auth/**").permitAll()

                // OAuth2 login endpoints
                .requestMatchers("/oauth2/**").permitAll()
                .requestMatchers("/login/**").permitAll()

                // Admin endpoints restricted to ADMIN role
                .requestMatchers("/api/admin/**").hasRole("ADMIN")

                // Only admins can create/update/delete posts
                .requestMatchers(HttpMethod.POST, "/api/posts/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/api/posts/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/posts/**").hasRole("ADMIN")

                // Only admins can create/update/delete comments
                .requestMatchers(HttpMethod.POST, "/api/comments/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/api/comments/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/comments/**").hasRole("ADMIN")

                // GET requests for posts, comments, categories open to any authenticated user
                .requestMatchers(HttpMethod.GET, "/api/posts/**").authenticated()
                .requestMatchers(HttpMethod.GET, "/api/comments/**").authenticated()
                .requestMatchers(HttpMethod.GET, "/api/categories/**").authenticated()

                // User-specific endpoints
                .requestMatchers("/api/user/**").hasAnyRole("USER", "ADMIN")

                // Any other request requires authentication
                .anyRequest().authenticated()
            )
            .exceptionHandling(exception ->
                exception.accessDeniedHandler(accessDeniedHandler())
            )
            // ✅ Combine JWT (stateless) + OAuth2 login
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            .oauth2Login(oauth2 -> oauth2
                .loginPage("/login")   // custom login page (optional)
                .userInfoEndpoint(userInfo -> userInfo.userService(customOAuth2UserService))
                .successHandler(oAuth2LoginSuccessHandler)
            );

        // Add JWT filter before UsernamePasswordAuthenticationFilter
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration cfg) throws Exception {
        return cfg.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AccessDeniedHandler accessDeniedHandler() {
        return (HttpServletRequest request, HttpServletResponse response,
                org.springframework.security.access.AccessDeniedException accessDeniedException) -> {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json");

            Map<String, Object> body = new HashMap<>();
            body.put("timestamp", LocalDateTime.now());
            body.put("status", 403);
            body.put("error", "Forbidden");
            body.put("message", "Access Denied");
            body.put("path", request.getRequestURI());

            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(response.getOutputStream(), body);
        };
    }
}
