package com.app.payloads;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public class CategoryDto {

    private Integer categoryId;
    
    @NotEmpty(message = "Title cannot be empty")
    @Size(max = 100, message = "Title must be at most 100 characters")
    private String categoryTitle;

    @NotEmpty(message = "Description cannot be empty")
    @Size(max = 250, message = "Description must be at most 250 characters")
    private String categoryDescription;


    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryTitle() {
        return categoryTitle;
    }

    public void setCategoryTitle(String categoryTitle) {
        this.categoryTitle = categoryTitle;
    }

    public String getCategoryDescription() {
        return categoryDescription;
    }

    public void setCategoryDescription(String categoryDescription) {
        this.categoryDescription = categoryDescription;
    }
}
