package com.app.payloads;

public class ImageResponse {
    private String fileName;
    private String message;
    private boolean success;

    public ImageResponse() {
    }

    public ImageResponse(String fileName, String message, boolean success) {
        this.fileName = fileName;
        this.message = message;
        this.success = success;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }
}
