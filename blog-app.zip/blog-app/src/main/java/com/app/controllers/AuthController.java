package com.app.controllers;

import com.app.entities.Role;
import com.app.entities.User;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.JwtAuthRequest;
import com.app.payloads.JwtAuthResponse;
import com.app.repositories.RoleRepo;
import com.app.repositories.UserRepo;
import com.app.security.CustomUserDetailsService;
import com.app.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private RoleRepo roleRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ------------------ LOGIN ------------------
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody JwtAuthRequest request) {
        try {
            // Step 1: Authenticate user credentials
            Authentication authentication = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );

            // Step 2: Load Spring Security UserDetails
            org.springframework.security.core.userdetails.User userDetails =
                    (org.springframework.security.core.userdetails.User) userDetailsService
                            .loadUserByUsername(request.getEmail());

            // Step 3: Generate JWT token
            String token = jwtUtil.generateToken(userDetails.getUsername()); // FIXED

            return ResponseEntity.ok(new JwtAuthResponse(token));
        } catch (BadCredentialsException ex) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }


    // ------------------ REGISTER ------------------
    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody User user) {
        // Encode password
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Assign default ROLE_USER if roles empty
        if (user.getRoles() == null || user.getRoles().isEmpty()) {
            Optional<Role> defaultRole = roleRepo.findById(2); // id=2 must be ROLE_USER in DB
            Set<Role> rolesSet = new HashSet<>();
            defaultRole.ifPresent(rolesSet::add);
            user.setRoles(rolesSet);
        }

        // Save user
        User saved = userRepo.save(user);

        // Hide password in response
        saved.setPassword(null);

        return ResponseEntity.ok(saved);
    }
    
    @PutMapping("/assign-role/{userId}")
    public ResponseEntity<User> assignRole(@PathVariable Integer userId, @RequestBody Set<Role> roles) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        user.setRoles(roles);
        User updatedUser = userRepo.save(user);
        updatedUser.setPassword(null);
        return ResponseEntity.ok(updatedUser);
    }

}
