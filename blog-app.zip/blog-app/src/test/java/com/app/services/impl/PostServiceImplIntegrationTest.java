package com.app.services.impl;

import com.app.entities.Category;
import com.app.entities.Post;
import com.app.entities.User;
import com.app.payloads.PostDto;
import com.app.payloads.PostResponse;
import com.app.repositories.CategoryRepo;
import com.app.repositories.PostRepo;
import com.app.repositories.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class PostServiceImplIntegrationTest {

    @Autowired
    private PostServiceImpl postService;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private PostRepo postRepo;

    @Autowired
    private ModelMapper modelMapper;

    private User user;
    private Category category;
    private Post post;

    @BeforeEach
    void setUp() {
        // Create and save user
        user = new User();
        user.setName("John Doe");
        user.setEmail("john@example.com");
        user.setPassword("password");
        user = userRepo.save(user);

        // Create and save category
        category = new Category();
        category.setCategoryTitle("Tech");
        category.setCategoryDescription("Tech Category");
        category = categoryRepo.save(category);

        // Create and save post
        post = new Post();
        post.setTitle("My First Post");
        post.setContent("This is the post content");
        post.setUser(user);
        post.setCategory(category);
        post = postRepo.save(post);
    }

    @Test
    void testCreatePost() {
        PostDto postDto = new PostDto();
        postDto.setTitle("New Post");
        postDto.setContent("New Content");
        postDto.setUser(modelMapper.map(user, com.app.payloads.UserDto.class));
        postDto.setCategory(modelMapper.map(category, com.app.payloads.CategoryDto.class));

        PostDto created = postService.createPost(postDto);

        assertNotNull(created);
        assertEquals("New Post", created.getTitle());
        assertEquals("New Content", created.getContent());
    }

    @Test
    void testUpdatePost() {
        PostDto updateDto = new PostDto();
        updateDto.setTitle("Updated Title");
        updateDto.setContent("Updated Content");
        updateDto.setUser(modelMapper.map(user, com.app.payloads.UserDto.class));
        updateDto.setCategory(modelMapper.map(category, com.app.payloads.CategoryDto.class));

        PostDto updated = postService.updatePost(updateDto, post.getPostId());

        assertEquals("Updated Title", updated.getTitle());
        assertEquals("Updated Content", updated.getContent());
    }

    @Test
    void testDeletePost() {
        assertDoesNotThrow(() -> postService.deletePost(post.getPostId()));
        assertFalse(postRepo.findById(post.getPostId()).isPresent());
    }

    @Test
    void testGetPostById() {
        PostDto fetched = postService.getPostById(post.getPostId());

        assertNotNull(fetched);
        assertEquals("My First Post", fetched.getTitle());
    }

    @Test
    void testGetAllPost() {
        PostResponse response = postService.getAllPost(0, 10, "postId", "asc");

        assertNotNull(response);
        assertEquals(1, response.getContent().size()); // Only 1 post in setup
        assertEquals("My First Post", response.getContent().get(0).getTitle());
    }

    @Test
    void testGetPostByUser() {
        List<PostDto> posts = postService.getPostByUser(user.getId());

        assertEquals(1, posts.size());
        assertEquals("My First Post", posts.get(0).getTitle());
    }

    @Test
    void testGetPostByCategory() {
        List<PostDto> posts = postService.getPostByCategory(category.getCategoryId());

        assertEquals(1, posts.size());
        assertEquals("My First Post", posts.get(0).getTitle());
    }

    @Test
    void testSearchPosts() {
        List<PostDto> posts = postService.searchPosts("First");

        assertEquals(1, posts.size());
        assertEquals("My First Post", posts.get(0).getTitle());
    }
}
