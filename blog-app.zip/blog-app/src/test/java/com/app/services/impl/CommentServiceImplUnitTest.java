package com.app.services.impl;

import com.app.entities.Comment;
import com.app.entities.Post;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.CommentDto;
import com.app.repositories.CommentRepo;
import com.app.repositories.PostRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CommentServiceImplUnitTest {

    @InjectMocks
    private CommentServiceImpl commentService;

    @Mock
    private CommentRepo commentRepo;

    @Mock
    private PostRepo postRepo;

    @Mock
    private ModelMapper modelMapper;

    private Post post;
    private Comment comment;
    private CommentDto commentDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        post = new Post();
        post.setPostId(1);
        post.setTitle("Test Post");
        post.setContent("Content");

        comment = new Comment();
        comment.setId(1);
        comment.setContent("Test Comment");
        comment.setPost(post);

        commentDto = new CommentDto();
        commentDto.setContent("Test Comment");
        commentDto.setPostId(post.getPostId());
    }

    @Test
    void testCreateComment() {
        when(postRepo.findById(1)).thenReturn(Optional.of(post));
        when(commentRepo.save(any(Comment.class))).thenReturn(comment);

        CommentDto result = commentService.createComment(commentDto, 1);

        assertEquals("Test Comment", result.getContent());
        assertEquals(1, result.getPostId());
        verify(commentRepo, times(1)).save(any(Comment.class));
    }

    @Test
    void testCreateComment_PostNotFound() {
        when(postRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> commentService.createComment(commentDto, 1));
    }

    @Test
    void testGetCommentsByPost() {
        when(postRepo.findById(1)).thenReturn(Optional.of(post));
        when(commentRepo.findByPost(post)).thenReturn(Arrays.asList(comment));

        List<CommentDto> comments = commentService.getCommentsByPost(1);

        assertEquals(1, comments.size());
        assertEquals("Test Comment", comments.get(0).getContent());
    }

    @Test
    void testUpdateComment() {
        CommentDto updatedDto = new CommentDto();
        updatedDto.setContent("Updated Comment");

        when(commentRepo.findById(1)).thenReturn(Optional.of(comment));
        when(commentRepo.save(comment)).thenReturn(comment);
        when(modelMapper.map(comment, CommentDto.class)).thenReturn(updatedDto);

        CommentDto result = commentService.updateComment(updatedDto, 1);

        assertEquals("Updated Comment", result.getContent());
    }

    @Test
    void testDeleteComment() {
        when(commentRepo.findById(1)).thenReturn(Optional.of(comment));
        doNothing().when(commentRepo).delete(comment);

        assertDoesNotThrow(() -> commentService.deleteComment(1));
        verify(commentRepo, times(1)).delete(comment);
    }

    @Test
    void testDeleteComment_NotFound() {
        when(commentRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> commentService.deleteComment(1));
    }
}
