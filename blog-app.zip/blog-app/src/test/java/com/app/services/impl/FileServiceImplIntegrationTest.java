package com.app.services.impl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.util.FileSystemUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class FileServiceImplIntegrationTest {

    @Autowired
    private FileServiceImpl fileService;

    private final String uploadDir = "integration-uploads";

    @BeforeEach
    void setUp() {
        // Clean folder before every test
        FileSystemUtils.deleteRecursively(new File(uploadDir));
    }

    @Test
    void testUploadAndGetResource() throws IOException {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "test-integration.txt",
                "text/plain",
                "Integration Test Content".getBytes()
        );

        String fileName = fileService.uploadImage(uploadDir, file);
        assertNotNull(fileName);

        InputStream is = fileService.getResource(uploadDir, fileName);
        assertNotNull(is);

        byte[] content = is.readAllBytes();
        assertEquals("Integration Test Content", new String(content));
        is.close();
    }

    @Test
    void testFileOverwriteAvoided() throws IOException {
        MockMultipartFile file1 = new MockMultipartFile(
                "file",
                "duplicate.txt",
                "text/plain",
                "First".getBytes()
        );

        MockMultipartFile file2 = new MockMultipartFile(
                "file",
                "duplicate.txt",
                "text/plain",
                "Second".getBytes()
        );

        String name1 = fileService.uploadImage(uploadDir, file1);
        String name2 = fileService.uploadImage(uploadDir, file2);

        // Ensure random UUID prevents overwrite
        assertNotEquals(name1, name2);

        InputStream is1 = fileService.getResource(uploadDir, name1);
        InputStream is2 = fileService.getResource(uploadDir, name2);

        assertEquals("First", new String(is1.readAllBytes()));
        assertEquals("Second", new String(is2.readAllBytes()));

        is1.close();
        is2.close();
    }
}
