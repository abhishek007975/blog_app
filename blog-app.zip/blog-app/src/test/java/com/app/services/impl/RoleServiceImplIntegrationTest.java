package com.app.services.impl;

import com.app.entities.Role;
import com.app.repositories.RoleRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class RoleServiceImplIntegrationTest {

    @Autowired
    private RoleServiceImpl roleService;

    @Autowired
    private RoleRepo roleRepo;

    private Role role;

    @BeforeEach
    void setUp() {
        // Clean DB before each test
        roleRepo.deleteAll();

        role = new Role();
        role.setName("ADMIN");
        role = roleService.createRole(role);
    }

    @Test
    void testCreateRole() {
        Role newRole = new Role();
        newRole.setName("USER");

        Role created = roleService.createRole(newRole);

        assertNotNull(created.getId());
        assertEquals("USER", created.getName());
    }

    @Test
    void testGetRoleById() {
        Role found = roleService.getRoleById(role.getId());
        assertEquals("ADMIN", found.getName());
    }

    @Test
    void testGetAllRoles() {
        List<Role> roles = roleService.getAllRoles();
        assertEquals(1, roles.size());
        assertEquals("ADMIN", roles.get(0).getName());
    }

    @Test
    void testUpdateRole() {
        Role updatedRole = new Role();
        updatedRole.setName("SUPER_ADMIN");

        Role result = roleService.updateRole(updatedRole, role.getId());
        assertEquals("SUPER_ADMIN", result.getName());
    }

    @Test
    void testDeleteRole() {
        assertDoesNotThrow(() -> roleService.deleteRole(role.getId()));
        assertTrue(roleService.getAllRoles().isEmpty());
    }
}
