package com.app.services.impl;

import com.app.entities.Role;
import com.app.entities.User;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.UserDto;
import com.app.repositories.RoleRepo;
import com.app.repositories.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceImplUnitTest {

    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private UserRepo userRepo;

    @Mock
    private RoleRepo roleRepo;

    @Mock
    private ModelMapper modelMapper;

    @Mock
    private PasswordEncoder passwordEncoder;

    private User user;
    private UserDto userDto;
    private Role defaultRole;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        defaultRole = new Role();
        defaultRole.setId(1);
        defaultRole.setName("ROLE_USER");

        user = new User();
        user.setId(1);
        user.setName("Abhishek");
        user.setEmail("test@example.com");
        user.setPassword("password");
        user.setRoles(new HashSet<>(Collections.singleton(defaultRole)));

        userDto = new UserDto();
        userDto.setName("Abhishek");
        userDto.setEmail("test@example.com");
        userDto.setPassword("password");
        userDto.setAbout("About me");
    }

    @Test
    void testCreateUser_DefaultRoleAssigned() {
        when(modelMapper.map(userDto, User.class)).thenReturn(user);
        when(passwordEncoder.encode("password")).thenReturn("encodedPassword");
        when(roleRepo.findByName("ROLE_USER")).thenReturn(Optional.of(defaultRole));
        when(userRepo.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserDto.class)).thenReturn(userDto);

        UserDto created = userService.createUser(userDto);

        assertNotNull(created);
        assertEquals("Abhishek", created.getName());
        verify(userRepo, times(1)).save(user);
        verify(passwordEncoder, times(1)).encode("password");
    }

    @Test
    void testUpdateUser() {
        UserDto updateDto = new UserDto();
        updateDto.setName("Abhi");
        updateDto.setEmail("abhi@example.com");
        updateDto.setPassword("newpass");
        updateDto.setAbout("Updated about");

        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        when(passwordEncoder.encode("newpass")).thenReturn("encodedNewPass");
        when(userRepo.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserDto.class)).thenReturn(updateDto);

        UserDto result = userService.UpdateUser(updateDto, 1);

        assertEquals("Abhi", result.getName());
        verify(userRepo, times(1)).save(user);
    }

    @Test
    void testGetUserById() {
        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        when(modelMapper.map(user, UserDto.class)).thenReturn(userDto);

        UserDto result = userService.getUserById(1);

        assertEquals("Abhishek", result.getName());
        verify(userRepo, times(1)).findById(1);
    }

    @Test
    void testGetUserById_NotFound() {
        when(userRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> userService.getUserById(1));
    }

    @Test
    void testGetAllUsers() {
        List<User> users = Collections.singletonList(user);
        when(userRepo.findAll()).thenReturn(users);
        when(modelMapper.map(user, UserDto.class)).thenReturn(userDto);

        List<UserDto> result = userService.getAllUsers();

        assertEquals(1, result.size());
    }

    @Test
    void testDeleteUser() {
        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        doNothing().when(userRepo).delete(user);

        assertDoesNotThrow(() -> userService.deleteUser(1));
        verify(userRepo, times(1)).delete(user);
    }

    @Test
    void testGetUserByEmail() {
        when(userRepo.findByEmail("test@example.com")).thenReturn(Optional.of(user));

        User found = userService.getUserByEmail("test@example.com");
        assertEquals("Abhishek", found.getName());
    }

    @Test
    void testGetUserByEmail_NotFound() {
        when(userRepo.findByEmail("notfound@example.com")).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> userService.getUserByEmail("notfound@example.com"));
    }
}
