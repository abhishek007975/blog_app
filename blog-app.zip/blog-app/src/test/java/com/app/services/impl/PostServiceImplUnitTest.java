package com.app.services.impl;

import com.app.entities.Category;
import com.app.entities.Post;
import com.app.entities.User;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.CategoryDto;
import com.app.payloads.PostDto;
import com.app.payloads.UserDto;
import com.app.repositories.CategoryRepo;
import com.app.repositories.PostRepo;
import com.app.repositories.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PostServiceImplUnitTest {

    @InjectMocks
    private PostServiceImpl postService;

    @Mock
    private PostRepo postRepo;

    @Mock
    private UserRepo userRepo;

    @Mock
    private CategoryRepo categoryRepo;

    @Mock
    private ModelMapper modelMapper;

    private User user;
    private Category category;
    private Post post;
    private PostDto postDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        user = new User();
        user.setId(1);
        user.setName("John");

        category = new Category();
        category.setCategoryId(1);
        category.setCategoryTitle("Tech");

        post = new Post();
        post.setPostId(1);
        post.setTitle("Post Title");
        post.setContent("Post Content");
        post.setUser(user);
        post.setCategory(category);

        postDto = new PostDto();
        postDto.setTitle("Post Title");
        postDto.setContent("Post Content");
        postDto.setUser(new UserDto());
        postDto.getUser().setId(1);
        postDto.setCategory(new CategoryDto());
        postDto.getCategory().setCategoryId(1);
    }

    @Test
    void testCreatePost() {
        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        when(categoryRepo.findById(1)).thenReturn(Optional.of(category));
        when(modelMapper.map(postDto, Post.class)).thenReturn(post);
        when(postRepo.save(post)).thenReturn(post);
        when(modelMapper.map(post, PostDto.class)).thenReturn(postDto);

        PostDto created = postService.createPost(postDto);

        assertNotNull(created);
        assertEquals("Post Title", created.getTitle());
        verify(postRepo, times(1)).save(post);
    }

    @Test
    void testUpdatePost() {
        PostDto updateDto = new PostDto();
        updateDto.setTitle("Updated");
        updateDto.setContent("Updated Content");
        updateDto.setUser(new UserDto());
        updateDto.getUser().setId(1);
        updateDto.setCategory(new CategoryDto());
        updateDto.getCategory().setCategoryId(1);

        when(postRepo.findById(1)).thenReturn(Optional.of(post));
        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        when(categoryRepo.findById(1)).thenReturn(Optional.of(category));
        when(postRepo.save(post)).thenReturn(post);
        when(modelMapper.map(post, PostDto.class)).thenReturn(updateDto);

        PostDto result = postService.updatePost(updateDto, 1);

        assertEquals("Updated", result.getTitle());
        assertEquals("Updated Content", result.getContent());
        verify(postRepo, times(1)).save(post);
    }

    @Test
    void testDeletePost() {
        when(postRepo.findById(1)).thenReturn(Optional.of(post));
        doNothing().when(postRepo).delete(post);

        assertDoesNotThrow(() -> postService.deletePost(1));
        verify(postRepo, times(1)).delete(post);
    }

    @Test
    void testGetAllPost() {
        Page<Post> page = new PageImpl<>(List.of(post));
        Pageable pageable = PageRequest.of(0, 10, Sort.by("postId").ascending());

        when(postRepo.findAll(pageable)).thenReturn(page);
        when(modelMapper.map(post, PostDto.class)).thenReturn(postDto);

        var response = postService.getAllPost(0, 10, "postId", "asc");

        assertEquals(1, response.getContent().size());
        assertEquals("Post Title", response.getContent().get(0).getTitle());
    }

    @Test
    void testGetPostById_NotFound() {
        when(postRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> postService.getPostById(1));
    }
}
