package com.app.services.impl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.util.FileSystemUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.*;

class FileServiceImplUnitTest {

    private FileServiceImpl fileService;

    private final String uploadDir = "test-uploads";

    @BeforeEach
    void setUp() {
        fileService = new FileServiceImpl();
        // Clean test folder before each test
        FileSystemUtils.deleteRecursively(new File(uploadDir));
    }

    @Test
    void testUploadImage() throws IOException {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "test-image.jpg",
                "image/jpeg",
                "Test Content".getBytes()
        );

        String fileName = fileService.uploadImage(uploadDir, file);

        // Check file name is returned and file exists
        assertNotNull(fileName);
        File savedFile = Paths.get(uploadDir, fileName).toFile();
        assertTrue(savedFile.exists());
    }

    @Test
    void testGetResource() throws IOException {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "sample.txt",
                "text/plain",
                "Hello World".getBytes()
        );

        String fileName = fileService.uploadImage(uploadDir, file);
        InputStream is = fileService.getResource(uploadDir, fileName);

        assertNotNull(is);
        byte[] content = is.readAllBytes();
        assertEquals("Hello World", new String(content));
        is.close();
    }
}
