package com.app.services.impl;

import com.app.entities.Category;
import com.app.payloads.CategoryDto;
import com.app.repositories.CategoryRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@Transactional
public class CategoryServiceImplIntegratedTesting {

    @Autowired
    private CategoryServiceImpl categoryService;

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private ModelMapper modelMapper;

    private CategoryDto categoryDto;

    @BeforeEach
    void setUp() {
        categoryRepo.deleteAll(); // <-- clean the table
        categoryDto = new CategoryDto();
        categoryDto.setCategoryTitle("Tech");
        categoryDto.setCategoryDescription("Tech Description");
    }


    @Test
    void testCreateAndGetCategory() {
        CategoryDto created = categoryService.createCategory(categoryDto);
        assertNotNull(created.getCategoryId());
        assertEquals("Tech", created.getCategoryTitle());

        CategoryDto fetched = categoryService.getCategoryById(created.getCategoryId());
        assertEquals("Tech", fetched.getCategoryTitle());
    }

    @Test
    void testUpdateCategory() {
        CategoryDto created = categoryService.createCategory(categoryDto);

        CategoryDto updateDto = new CategoryDto();
        updateDto.setCategoryTitle("Updated");
        updateDto.setCategoryDescription("Updated Desc");

        CategoryDto updated = categoryService.updateCategory(updateDto, created.getCategoryId());
        assertEquals("Updated", updated.getCategoryTitle());
        assertEquals("Updated Desc", updated.getCategoryDescription());
    }

    @Test
    void testGetAllCategories() {
        categoryService.createCategory(categoryDto);

        List<CategoryDto> all = categoryService.getAllCategories();
        assertFalse(all.isEmpty());
        assertEquals(1, all.size());
        assertEquals("Tech", all.get(0).getCategoryTitle());
    }

    @Test
    void testDeleteCategory() {
        CategoryDto created = categoryService.createCategory(categoryDto);

        assertDoesNotThrow(() -> categoryService.deleteCategory(created.getCategoryId()));
        Optional<Category> deleted = categoryRepo.findById(created.getCategoryId());
        assertTrue(deleted.isEmpty());
    }

    @Test
    void testGetCategoryById_NotFound() {
        assertThrows(RuntimeException.class, () -> categoryService.getCategoryById(999));
    }
}
