package com.app.services.impl;

import com.app.entities.Role;
import com.app.exceptions.ResourceNotFoundException;
import com.app.repositories.RoleRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RoleServiceImplUnitTest {

    @InjectMocks
    private RoleServiceImpl roleService;

    @Mock
    private RoleRepo roleRepo;

    private Role role;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        role = new Role();
        role.setId(1);
        role.setName("ADMIN");
    }

    @Test
    void testCreateRole() {
        when(roleRepo.save(role)).thenReturn(role);

        Role created = roleService.createRole(role);

        assertNotNull(created);
        assertEquals("ADMIN", created.getName());
        verify(roleRepo, times(1)).save(role);
    }

    @Test
    void testUpdateRole() {
        Role updatedRole = new Role();
        updatedRole.setName("USER");

        when(roleRepo.findById(1)).thenReturn(Optional.of(role));
        when(roleRepo.save(role)).thenReturn(updatedRole);

        Role result = roleService.updateRole(updatedRole, 1);

        assertEquals("USER", result.getName());
        verify(roleRepo, times(1)).save(role);
    }

    @Test
    void testGetRoleById() {
        when(roleRepo.findById(1)).thenReturn(Optional.of(role));

        Role result = roleService.getRoleById(1);

        assertNotNull(result);
        assertEquals("ADMIN", result.getName());
        verify(roleRepo, times(1)).findById(1);
    }

    @Test
    void testGetRoleById_NotFound() {
        when(roleRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> roleService.getRoleById(1));
        verify(roleRepo, times(1)).findById(1);
    }

    @Test
    void testGetAllRoles() {
        List<Role> roles = Arrays.asList(role);
        when(roleRepo.findAll()).thenReturn(roles);

        List<Role> result = roleService.getAllRoles();

        assertEquals(1, result.size());
        verify(roleRepo, times(1)).findAll();
    }

    @Test
    void testDeleteRole() {
        when(roleRepo.findById(1)).thenReturn(Optional.of(role));
        doNothing().when(roleRepo).delete(role);

        assertDoesNotThrow(() -> roleService.deleteRole(1));
        verify(roleRepo, times(1)).delete(role);
    }

    @Test
    void testDeleteRole_NotFound() {
        when(roleRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> roleService.deleteRole(1));
        verify(roleRepo, never()).delete(any());
    }
}
