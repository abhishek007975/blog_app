package com.app.services.impl;

import com.app.entities.Role;
import com.app.entities.User;
import com.app.payloads.UserDto;
import com.app.repositories.RoleRepo;
import com.app.repositories.UserRepo;
import com.app.services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class UserServiceImplIntegrationTest {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private RoleRepo roleRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private ModelMapper modelMapper;

    private UserDto userDto;

    @BeforeEach
    void setUp() {
        // Clean DB before each test
        userRepo.deleteAll();
        roleRepo.deleteAll();

        // Ensure default role exists
        Role defaultRole = new Role();
        defaultRole.setName("ROLE_USER");
        roleRepo.save(defaultRole);

        // Prepare user DTO
        userDto = new UserDto();
        userDto.setName("Abhishek");
        userDto.setEmail("test@example.com");
        userDto.setPassword("password123");
        userDto.setAbout("About me");
    }

    @Test
    void testCreateUser() {
        UserDto savedUser = userService.createUser(userDto);

        assertNotNull(savedUser);
        assertEquals("Abhishek", savedUser.getName());
        assertEquals("test@example.com", savedUser.getEmail());

        // Password should be encoded
        User userEntity = userRepo.findById(savedUser.getId()).orElse(null);
        assertNotNull(userEntity);
        assertTrue(passwordEncoder.matches("password123", userEntity.getPassword()));
    }

    @Test
    void testGetAllUsers() {
        userService.createUser(userDto);

        List<UserDto> users = userService.getAllUsers();

        assertEquals(1, users.size());
        assertEquals("Abhishek", users.get(0).getName());
    }

    @Test
    void testGetUserById() {
        UserDto savedUser = userService.createUser(userDto);

        UserDto fetchedUser = userService.getUserById(savedUser.getId());

        assertNotNull(fetchedUser);
        assertEquals(savedUser.getName(), fetchedUser.getName());
        assertEquals(savedUser.getEmail(), fetchedUser.getEmail());
    }

    @Test
    void testUpdateUser() {
        UserDto savedUser = userService.createUser(userDto);

        UserDto updateDto = new UserDto();
        updateDto.setName("UpdatedName");
        updateDto.setEmail("updated@example.com");
        updateDto.setPassword("newpass");
        updateDto.setAbout("Updated About");

        UserDto updatedUser = userService.UpdateUser(updateDto, savedUser.getId());

        assertEquals("UpdatedName", updatedUser.getName());
        assertEquals("updated@example.com", updatedUser.getEmail());

        // Password should be updated and encoded
        User userEntity = userRepo.findById(savedUser.getId()).orElseThrow();
        assertTrue(passwordEncoder.matches("newpass", userEntity.getPassword()));
    }

    @Test
    void testDeleteUser() {
        UserDto savedUser = userService.createUser(userDto);

        assertDoesNotThrow(() -> userService.deleteUser(savedUser.getId()));

        assertFalse(userRepo.findById(savedUser.getId()).isPresent());
    }

    @Test
    void testGetUserByEmail() {
        userService.createUser(userDto);

        User userEntity = userService.getUserByEmail("test@example.com");

        assertNotNull(userEntity);
        assertEquals("Abhishek", userEntity.getName());
    }
}
