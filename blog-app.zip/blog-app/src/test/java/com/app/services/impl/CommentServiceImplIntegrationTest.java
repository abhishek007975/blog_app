package com.app.services.impl;

import com.app.entities.Comment;
import com.app.entities.Post;
import com.app.payloads.CommentDto;
import com.app.repositories.CommentRepo;
import com.app.repositories.PostRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class CommentServiceImplIntegrationTest {

    @Autowired
    private CommentServiceImpl commentService;

    @Autowired
    private PostRepo postRepo;

    @Autowired
    private CommentRepo commentRepo;

    private Post post;

    @BeforeEach
    void setUp() {
        commentRepo.deleteAll();
        postRepo.deleteAll();

        post = new Post();
        post.setTitle("Integration Test Post");
        post.setContent("Content");
        postRepo.save(post);
    }

    @Test
    void testCreateComment() {
        CommentDto dto = new CommentDto();
        dto.setContent("Integration Comment");

        CommentDto created = commentService.createComment(dto, post.getPostId());

        assertNotNull(created.getId());
        assertEquals("Integration Comment", created.getContent());
        assertEquals(post.getPostId(), created.getPostId());
    }

    @Test
    void testGetCommentsByPost() {
        CommentDto dto1 = new CommentDto();
        dto1.setContent("Comment 1");
        CommentDto dto2 = new CommentDto();
        dto2.setContent("Comment 2");

        commentService.createComment(dto1, post.getPostId());
        commentService.createComment(dto2, post.getPostId());

        List<CommentDto> comments = commentService.getCommentsByPost(post.getPostId());

        assertEquals(2, comments.size());
        assertTrue(comments.stream().anyMatch(c -> c.getContent().equals("Comment 1")));
        assertTrue(comments.stream().anyMatch(c -> c.getContent().equals("Comment 2")));
    }

    @Test
    void testUpdateComment() {
        CommentDto dto = new CommentDto();
        dto.setContent("Original Comment");
        CommentDto created = commentService.createComment(dto, post.getPostId());

        CommentDto updateDto = new CommentDto();
        updateDto.setContent("Updated Comment");

        CommentDto updated = commentService.updateComment(updateDto, created.getId());

        assertEquals("Updated Comment", updated.getContent());
    }

    @Test
    void testDeleteComment() {
        CommentDto dto = new CommentDto();
        dto.setContent("To Delete");
        CommentDto created = commentService.createComment(dto, post.getPostId());

        assertDoesNotThrow(() -> commentService.deleteComment(created.getId()));

        List<CommentDto> comments = commentService.getCommentsByPost(post.getPostId());
        assertEquals(0, comments.size());
    }
}
