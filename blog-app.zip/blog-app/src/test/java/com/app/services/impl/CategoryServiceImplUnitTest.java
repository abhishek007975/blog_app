package com.app.services.impl;

import com.app.entities.Category;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.CategoryDto;
import com.app.repositories.CategoryRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CategoryServiceImplUnitTest {

    @InjectMocks
    private CategoryServiceImpl categoryService;

    @Mock
    private CategoryRepo categoryRepo;

    @Mock
    private ModelMapper modelMapper;

    private Category category;
    private CategoryDto categoryDto;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        category = new Category();
        category.setCategoryId(1); 
        category.setCategoryTitle("Tech");
        category.setCategoryDescription("Tech Description");

        categoryDto = new CategoryDto();
        categoryDto.setCategoryTitle("Tech");
        categoryDto.setCategoryDescription("Tech Description");
    }

    @Test
    public void testCreateCategory() {
        when(modelMapper.map(categoryDto, Category.class)).thenReturn(category);
        when(categoryRepo.save(category)).thenReturn(category);
        when(modelMapper.map(category, CategoryDto.class)).thenReturn(categoryDto);

        CategoryDto created = categoryService.createCategory(categoryDto);

        assertNotNull(created);
        assertEquals("Tech", created.getCategoryTitle());
        verify(categoryRepo, times(1)).save(category);
    }

    @Test
    public void testUpdateCategory() {
        CategoryDto updatedDto = new CategoryDto();
        updatedDto.setCategoryTitle("Updated");
        updatedDto.setCategoryDescription("Updated Desc");

        Category updatedCategory = new Category();
        updatedCategory.setCategoryId(1);
        updatedCategory.setCategoryTitle("Updated");
        updatedCategory.setCategoryDescription("Updated Desc");

        when(categoryRepo.findById(1)).thenReturn(Optional.of(category));
        when(categoryRepo.save(category)).thenReturn(updatedCategory);
        when(modelMapper.map(updatedCategory, CategoryDto.class)).thenReturn(updatedDto);

        CategoryDto result = categoryService.updateCategory(updatedDto, 1);

        assertEquals("Updated", result.getCategoryTitle());
        assertEquals("Updated Desc", result.getCategoryDescription());
        verify(categoryRepo, times(1)).save(category);
    }

    @Test
    public void testGetCategoryById() {
        when(categoryRepo.findById(1)).thenReturn(Optional.of(category));
        when(modelMapper.map(category, CategoryDto.class)).thenReturn(categoryDto);

        CategoryDto result = categoryService.getCategoryById(1);

        assertNotNull(result);
        assertEquals("Tech", result.getCategoryTitle());
        verify(categoryRepo, times(1)).findById(1);
    }

    @Test
    public void testGetCategoryById_NotFound() {
        when(categoryRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> categoryService.getCategoryById(1));
        verify(categoryRepo, times(1)).findById(1);
    }

    @Test
    public void testGetAllCategories() {
        List<Category> categories = Arrays.asList(category);
        when(categoryRepo.findAll()).thenReturn(categories);
        when(modelMapper.map(category, CategoryDto.class)).thenReturn(categoryDto);

        List<CategoryDto> result = categoryService.getAllCategories();

        assertEquals(1, result.size());
        assertEquals("Tech", result.get(0).getCategoryTitle());
        verify(categoryRepo, times(1)).findAll();
    }

    @Test
    public void testDeleteCategory() {
        when(categoryRepo.findById(1)).thenReturn(Optional.of(category));
        doNothing().when(categoryRepo).delete(category);

        assertDoesNotThrow(() -> categoryService.deleteCategory(1));
        verify(categoryRepo, times(1)).delete(category);
    }

    @Test
    public void testDeleteCategory_NotFound() {
        when(categoryRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> categoryService.deleteCategory(1));
        verify(categoryRepo, never()).delete(any());
    }
}
