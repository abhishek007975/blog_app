package com.app.controllers;

import com.app.payloads.CommentDto;
import com.app.payloads.PostDto;
import com.app.payloads.PostResponse;
import com.app.services.CommentService;
import com.app.services.FileService;
import com.app.services.PostService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class PostControllerTest {

    @Mock
    private PostService postService;

    @Mock
    private FileService fileService;

    @Mock
    private CommentService commentService;

    @InjectMocks
    private PostController postController;

    private PostDto samplePost;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        samplePost = new PostDto();
        samplePost.setPostId(1);
        samplePost.setTitle("Test Post");
        samplePost.setContent("This is a test post");
        samplePost.setImageName("test.png");
        samplePost.setAddedDate(new Date());
    }

    @Test
    void testCreatePost() {
        when(postService.createPost(any(PostDto.class))).thenReturn(samplePost);

        ResponseEntity<PostDto> response = postController.createPost(samplePost);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Test Post", response.getBody().getTitle());
    }

    @Test
    void testUpdatePost() {
        when(postService.updatePost(any(PostDto.class), eq(1))).thenReturn(samplePost);

        ResponseEntity<PostDto> response = postController.updatePost(samplePost, 1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().getPostId());
    }

    @Test
    void testDeletePost() {
        doNothing().when(postService).deletePost(1);

        ResponseEntity<String> response = postController.deletePost(1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Post deleted successfully!", response.getBody());
    }

    @Test
    void testGetPostById() {
        when(postService.getPostById(1)).thenReturn(samplePost);

        ResponseEntity<PostDto> response = postController.getPostById(1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Test Post", response.getBody().getTitle());
    }

    @Test
    void testGetPostsByCategory() {
        when(postService.getPostByCategory(1)).thenReturn(Arrays.asList(samplePost));

        ResponseEntity<List<PostDto>> response = postController.getPostsByCategory(1);

        assertEquals(1, response.getBody().size());
    }

    @Test
    void testGetPostsByUser() {
        when(postService.getPostByUser(1)).thenReturn(Arrays.asList(samplePost));

        ResponseEntity<List<PostDto>> response = postController.getPostsByUser(1);

        assertEquals(1, response.getBody().size());
    }

    @Test
    void testSearchPosts() {
        when(postService.searchPosts("test")).thenReturn(Arrays.asList(samplePost));

        ResponseEntity<List<PostDto>> response = postController.searchPosts("test");

        assertEquals(1, response.getBody().size());
    }

    @Test
    void testUploadPostImage() throws IOException {
        MockMultipartFile file = new MockMultipartFile("image", "test.png",
                MediaType.IMAGE_PNG_VALUE, "dummy".getBytes());

        when(postService.getPostById(1)).thenReturn(samplePost);
        when(fileService.uploadImage(anyString(), any())).thenReturn("test.png");
        when(postService.updatePost(any(PostDto.class), eq(1))).thenReturn(samplePost);

        ResponseEntity<?> response = postController.uploadPostImage(file, 1);

        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    void testGetCommentsByPost() {
        CommentDto comment = new CommentDto();
        comment.setId(1);
        comment.setContent("Nice Post");
        comment.setPostId(1);

        when(commentService.getCommentsByPost(1)).thenReturn(Arrays.asList(comment));

        ResponseEntity<List<CommentDto>> response = postController.getCommentsByPost(1);

        assertEquals(1, response.getBody().size());
        assertEquals("Nice Post", response.getBody().get(0).getContent());
    }

    @Test
    void testDownloadImage() throws Exception {
        // Arrange
        samplePost.setImageName("test.png");
        ReflectionTestUtils.setField(postController, "path", "test-dir"); // inject dummy path

        byte[] imageBytes = "dummy-image-data".getBytes();

        when(postService.getPostById(1)).thenReturn(samplePost);
        when(fileService.getResource(anyString(), eq("test.png")))
                .thenReturn(new ByteArrayInputStream(imageBytes));

        MockHttpServletResponse mockResponse = new MockHttpServletResponse();

        // Act
        postController.downloadImage(1, mockResponse);

        // Assert
        assertEquals(200, mockResponse.getStatus());
        assertEquals("image/jpeg", mockResponse.getContentType());
        assertArrayEquals(imageBytes, mockResponse.getContentAsByteArray());
    }



}
