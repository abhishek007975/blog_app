package com.app.controllers;

import com.app.entities.Role;
import com.app.entities.User;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.JwtAuthRequest;
import com.app.payloads.JwtAuthResponse;
import com.app.repositories.RoleRepo;
import com.app.repositories.UserRepo;
import com.app.security.CustomUserDetailsService;
import com.app.security.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
public class AuthControllerIntegrationTest {

    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    @MockBean
    private AuthenticationManager authManager;

    @MockBean
    private CustomUserDetailsService userDetailsService;

    @MockBean
    private JwtUtil jwtUtil;

    @MockBean
    private UserRepo userRepo;

    @MockBean
    private RoleRepo roleRepo;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    private static String asJsonString(final Object obj) throws Exception {
        return new ObjectMapper().writeValueAsString(obj);
    }

    // ------------------ LOGIN SUCCESS ------------------
    @Test
    public void testLoginSuccess() throws Exception {
        JwtAuthRequest request = new JwtAuthRequest();
        request.setEmail("test@example.com");
        request.setPassword("password");

        UserDetails mockUserDetails = org.springframework.security.core.userdetails.User
                .withUsername("test@example.com")
                .password("password")
                .roles("USER")
                .build();

        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(new UsernamePasswordAuthenticationToken(mockUserDetails, null, mockUserDetails.getAuthorities()));
        when(userDetailsService.loadUserByUsername("test@example.com")).thenReturn(mockUserDetails);
        when(jwtUtil.generateToken("test@example.com")).thenReturn("fake-jwt-token");

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("fake-jwt-token"));
    }

    // ------------------ LOGIN FAIL ------------------
    @Test
    public void testLoginFail() throws Exception {
        JwtAuthRequest request = new JwtAuthRequest();
        request.setEmail("wrong@example.com");
        request.setPassword("wrongpassword");

        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(new BadCredentialsException("Invalid credentials"));

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(request)))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("Invalid credentials"));
    }

    // ------------------ REGISTER ------------------
    @Test
    public void testRegisterSuccess() throws Exception {
        User user = new User();
        user.setId(1);
        user.setEmail("newuser@example.com");
        user.setPassword("password");

        Role roleUser = new Role();
        roleUser.setId(2);
        roleUser.setName("ROLE_USER");

        when(roleRepo.findById(2)).thenReturn(Optional.of(roleUser));
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArguments()[0]);

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(user)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("newuser@example.com"))
                .andExpect(jsonPath("$.password").doesNotExist());
    }

    // ------------------ ASSIGN ROLE SUCCESS ------------------
    @Test
    public void testAssignRoleSuccess() throws Exception {
        User user = new User();
        user.setId(1);
        user.setEmail("user@example.com");
        user.setRoles(new HashSet<>());

        Role roleAdmin = new Role();
        roleAdmin.setId(1);
        roleAdmin.setName("ROLE_ADMIN");

        Set<Role> newRoles = new HashSet<>();
        newRoles.add(roleAdmin);

        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArguments()[0]);

        mockMvc.perform(put("/api/auth/assign-role/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(newRoles)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.roles[0].name").value("ROLE_ADMIN"))
                .andExpect(jsonPath("$.password").doesNotExist());
    }

    // ------------------ ASSIGN ROLE USER NOT FOUND ------------------
    @Test
    public void testAssignRoleUserNotFound() throws Exception {
        Set<Role> roles = new HashSet<>();
        Role roleAdmin = new Role();
        roleAdmin.setId(1);
        roleAdmin.setName("ROLE_ADMIN");
        roles.add(roleAdmin);

        when(userRepo.findById(999)).thenReturn(Optional.empty());

        mockMvc.perform(put("/api/auth/assign-role/999")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(roles)))
                .andExpect(status().isNotFound());
    }

}
