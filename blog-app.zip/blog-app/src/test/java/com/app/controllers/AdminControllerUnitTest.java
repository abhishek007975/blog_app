package com.app.controllers;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class AdminControllerUnitTest {

    @Test
    void testAdmin_ReturnsCorrectMessage() {
        // Arrange
        AdminController controller = new AdminController();

        // Act
        String response = controller.testAdmin();

        // Assert
        assertThat(response).isEqualTo("Hello Admin! You have access.");
    }
}
