package com.app.controllers;

import com.app.payloads.CommentDto;
import com.app.services.CommentService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class CommentControllerUnitTest {

    @Mock
    private CommentService commentService;

    @InjectMocks
    private CommentController commentController;

    public CommentControllerUnitTest() {
        MockitoAnnotations.openMocks(this); // initialize mocks
    }

    @Test
    void testAddComment() {
        CommentDto commentDto = new CommentDto();
        commentDto.setContent("Test comment");

        when(commentService.createComment(commentDto, 1)).thenReturn(commentDto);

        ResponseEntity<CommentDto> response = commentController.addComment(commentDto, 1);

        assertThat(response.getBody()).isEqualTo(commentDto);
        verify(commentService, times(1)).createComment(commentDto, 1);
    }

    @Test
    void testDeleteComment() {
        doNothing().when(commentService).deleteComment(1);

        ResponseEntity<String> response = commentController.deleteComment(1);

        assertThat(response.getBody()).isEqualTo("Comment deleted successfully!");
        verify(commentService, times(1)).deleteComment(1);
    }

    @Test
    void testGetCommentsByPost() {
        CommentDto c1 = new CommentDto();
        c1.setContent("Comment 1");
        CommentDto c2 = new CommentDto();
        c2.setContent("Comment 2");

        when(commentService.getCommentsByPost(1)).thenReturn(Arrays.asList(c1, c2));

        ResponseEntity<List<CommentDto>> response = commentController.getCommentsByPost(1);

        assertThat(response.getBody()).hasSize(2);
        verify(commentService, times(1)).getCommentsByPost(1);
    }

    @Test
    void testUpdateComment() {
        CommentDto input = new CommentDto();
        input.setContent("Updated");

        CommentDto updated = new CommentDto();
        updated.setContent("Updated");

        when(commentService.updateComment(input, 1)).thenReturn(updated);

        ResponseEntity<CommentDto> response = commentController.updateComment(input, 1);

        assertThat(response.getBody().getContent()).isEqualTo("Updated");
        verify(commentService, times(1)).updateComment(input, 1);
    }
}
