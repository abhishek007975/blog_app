package com.app.controllers;

import com.app.payloads.CategoryDto;
import com.app.services.CategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class CategoryControllerUnitTest {

    @Mock
    private CategoryService categoryService;

    @InjectMocks
    private CategoryController categoryController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateCategory() {
        CategoryDto dto = new CategoryDto();
        dto.setCategoryId(1);
        dto.setCategoryTitle("Tech");
        dto.setCategoryDescription("Technology category");

        when(categoryService.createCategory(any(CategoryDto.class))).thenReturn(dto);

        ResponseEntity<CategoryDto> response = categoryController.createCategory(dto);

        assertThat(response.getStatusCodeValue()).isEqualTo(201);
        assertThat(response.getBody()).isEqualTo(dto);
        verify(categoryService, times(1)).createCategory(dto);
    }

    @Test
    void testGetAllCategories() {
        CategoryDto dto1 = new CategoryDto();
        dto1.setCategoryId(1);
        dto1.setCategoryTitle("Tech");
        dto1.setCategoryDescription("Technology category");

        CategoryDto dto2 = new CategoryDto();
        dto2.setCategoryId(2);
        dto2.setCategoryTitle("Science");
        dto2.setCategoryDescription("Science category");

        List<CategoryDto> categories = Arrays.asList(dto1, dto2);
        when(categoryService.getAllCategories()).thenReturn(categories);

        ResponseEntity<List<CategoryDto>> response = categoryController.getAllCategories();

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody()).hasSize(2);
        verify(categoryService, times(1)).getAllCategories();
    }
}
