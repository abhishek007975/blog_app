package com.app.controllers;

import com.app.entities.Role;
import com.app.entities.User;
import com.app.exceptions.ResourceNotFoundException;
import com.app.payloads.JwtAuthRequest;
import com.app.payloads.JwtAuthResponse;
import com.app.repositories.RoleRepo;
import com.app.repositories.UserRepo;
import com.app.security.CustomUserDetailsService;
import com.app.security.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class AuthControllerTest {

    @InjectMocks
    private AuthController authController;

    @Mock
    private AuthenticationManager authManager;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private CustomUserDetailsService userDetailsService;

    @Mock
    private UserRepo userRepo;

    @Mock
    private RoleRepo roleRepo;

    @Mock
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // ------------------ LOGIN ------------------
    @Test
    void testLoginSuccess() {
        JwtAuthRequest request = new JwtAuthRequest();
        request.setEmail("test@example.com");
        request.setPassword("password");

        // Mock user details
        UserDetails mockUser = org.springframework.security.core.userdetails.User
                .withUsername("test@example.com")
                .password("password")
                .authorities("ROLE_USER")
                .build();

        // Mock Authentication
        Authentication mockAuth = mock(Authentication.class);
        when(mockAuth.getPrincipal()).thenReturn(mockUser);

        // Mocks
        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(mockAuth);
        when(userDetailsService.loadUserByUsername(request.getEmail())).thenReturn(mockUser);
        when(jwtUtil.generateToken(mockUser.getUsername())).thenReturn("mock-jwt-token");

        ResponseEntity<?> response = authController.login(request);

        assertEquals(200, response.getStatusCodeValue());
        assertTrue(response.getBody() instanceof JwtAuthResponse);
        assertEquals("mock-jwt-token", ((JwtAuthResponse) response.getBody()).getToken());
    }

    @Test
    void testLoginFailure() {
        JwtAuthRequest request = new JwtAuthRequest();
        request.setEmail("wrong@example.com");
        request.setPassword("wrongpass");

        when(authManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(new org.springframework.security.authentication.BadCredentialsException("Bad credentials"));

        ResponseEntity<?> response = authController.login(request);

        assertEquals(401, response.getStatusCodeValue());
        assertEquals("Invalid credentials", response.getBody());
    }

    // ------------------ REGISTER ------------------
    @Test
    void testRegisterUserWithDefaultRole() {
        User user = new User();
        user.setEmail("new@example.com");
        user.setPassword("password");

        Role defaultRole = new Role();
        defaultRole.setId(2);
        defaultRole.setName("ROLE_USER");

        when(passwordEncoder.encode(user.getPassword())).thenReturn("encoded-password");
        when(roleRepo.findById(2)).thenReturn(Optional.of(defaultRole));
        when(userRepo.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ResponseEntity<User> response = authController.register(user);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals("new@example.com", response.getBody().getEmail());
        assertNull(response.getBody().getPassword()); // password hidden
        assertTrue(response.getBody().getRoles().contains(defaultRole));
    }

    // ------------------ ASSIGN ROLE ------------------
    @Test
    void testAssignRoleSuccess() {
        User existingUser = new User();
        existingUser.setId(1);
        existingUser.setEmail("user@example.com");
        existingUser.setPassword("password");

        Role adminRole = new Role();
        adminRole.setId(1);
        adminRole.setName("ROLE_ADMIN");

        Set<Role> rolesToAssign = new HashSet<>();
        rolesToAssign.add(adminRole);

        when(userRepo.findById(1)).thenReturn(Optional.of(existingUser));
        when(userRepo.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ResponseEntity<User> response = authController.assignRole(1, rolesToAssign);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(existingUser.getEmail(), response.getBody().getEmail());
        assertTrue(response.getBody().getRoles().contains(adminRole));
        assertNull(response.getBody().getPassword());
    }

    @Test
    void testAssignRoleUserNotFound() {
        when(userRepo.findById(999)).thenReturn(Optional.empty());

        Set<Role> roles = new HashSet<>();
        ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class,
                () -> authController.assignRole(999, roles));

        assertEquals("User not found with id : 999", thrown.getMessage());
    }

}
